package adapter;

public interface Shape {
 public int getLimiteX();
 public int getLimiteY();
}
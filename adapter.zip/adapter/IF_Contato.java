package adapter;
/*
 * Created on 05/03/2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author 2004205172
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface IF_Contato {
	
	public String getNome();
	
	public String getTelefone();
	
	public void setNome(String nome);
	
	public void setTelefone(String telefone);
	
	
}

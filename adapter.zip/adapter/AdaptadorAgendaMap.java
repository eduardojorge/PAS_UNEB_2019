package adapter;

import java.util.Iterator;

public class AdaptadorAgendaMap implements IF_Agenda {
	
	private AgendaMap agendaMap=null;
	public AdaptadorAgendaMap(AgendaMap agendaMap_) {
		this.agendaMap = agendaMap_;
		
	}

	@Override
	public boolean adicionaContato(IF_Contato contato) {
		// TODO Auto-generated method stub
		
		return this.agendaMap.adiciona(contato);
	}

	@Override
	public IF_Contato getContato(String telefone) {
		// TODO Auto-generated method stub
		return (IF_Contato) this.agendaMap.getHashContato().get(telefone);
	}

	@Override
	public boolean removeContato(String telefone) {
		// TODO Auto-generated method stub
		return this.agendaMap.remove(telefone);
	}

	@Override
	public Iterator getListaContato() {
		// TODO Auto-generated method stub
		return this.agendaMap.getHashContato().values().iterator();
	}

	@Override
	public String getTelefoneContato(String _nome) {
		
		String tel = "Nao Encontrado";
		Iterator it = this.getListaContato();
		while(it.hasNext()){
			IF_Contato c = (IF_Contato) it.next();
			if(c.getNome().equals(_nome)){
				tel = c.getTelefone();
			}
		}
		return tel;
		// TODO Auto-generated method stub
		
	}
	
        public String toString(){
		
		String temp= "Lista de Contatos:\n";
		Iterator it = this.getListaContato();
		
		while(it.hasNext()){
			IF_Contato c = (IF_Contato)it.next();
			temp = temp + c+"\n";
		}
		return temp;
	}

}

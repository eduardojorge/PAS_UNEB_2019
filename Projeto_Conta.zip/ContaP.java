
public class ContaP extends Conta{
	
	private double indice;

	public double getIndice() {
		return indice;
	}

	public void setIndice(double indice) {
		this.indice = indice;
	}
	
	public void taxaConta(){
		if (!super.debitoConta(10*indice)){
		    super.setEstado(Conta.BLOCK);
		}
	}
	
	public String toString(){
		   return " Conta Popança "+super.toString();
	}

}

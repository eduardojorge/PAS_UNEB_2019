
public class TestaConta {
	

	private Conta conta;
	public Conta getConta() {
		return conta;
	}

	public void setC(Conta c) {
		this.conta = c;
	}
	
	public void taxaConta(){
		conta.taxaConta();
	}
	
	public void taxaContaMeses(int meses){
		
		for (int x=1;x<=meses;x++){
			System.out.println(conta);
			this.taxaConta();
		}
	}

}

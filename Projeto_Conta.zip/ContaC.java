
public class ContaC extends Conta {
	public void taxaConta(){
		if (!super.debitoConta(10)){
		    super.setEstado(Conta.BLOCK);
		}
	}
	
	public String toString(){
		   return " Conta Corrente "+super.toString();
	}

}


public abstract class Conta {
	
	private String numero;
	private double saldo;
	private double limite;
	private int estado;
	
	public static final int ABERTO=0;
	public static final int BLOCK=1;
	
	public Conta(){
		this.estado = Conta.ABERTO;
	}
	
	public String toString(){
		return  " Número:"+this.getNumero()+ 
				" Saldo:"+this.getSaldo() + 
				" Limite:"+this.getLimite()+
				(this.getEstado()==Conta.ABERTO?" Aberto":" Block");
	}
	public abstract void taxaConta();
	
	public boolean debitoConta(double valor){
		if ( (this.estado ==Conta.ABERTO ) && (this.saldo+this.limite>=valor)  ){
			this.saldo = this.saldo -valor;
			return true;
			
		}else{
			return false;
		}
	}
	
	public boolean creditoConta(double valor){
		if ( (this.estado ==Conta.ABERTO )  ){
			this.saldo = this.saldo +valor;
			return true;
			
		}else{
			return false;
		}
	}
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	public double getSaldo() {
		return saldo;
	}
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	public double getLimite() {
		return limite;
	}
	public void setLimite(double limite) {
		this.limite = limite;
	}
	public int getEstado() {
		return estado;
	}
	public void setEstado(int estado) {
		this.estado = estado;
	}
	
	public static void main(String args[]){
		Conta p = new ContaP();
		
		p.setNumero("1299-x");
		p.setSaldo(30);
		p.setLimite(10);
		((ContaP)p).setIndice(1.5);
		
		Conta c = new ContaC();
		
		c.setNumero("3456-0");
		c.setSaldo(30);
		c.setLimite(10);
		
		TestaConta testaConta = new TestaConta();
		testaConta.setC(p);
		testaConta.taxaContaMeses(10);
		
		
		testaConta.setC(c);
		testaConta.taxaContaMeses(10);
		
		
	}
	
	
	

}

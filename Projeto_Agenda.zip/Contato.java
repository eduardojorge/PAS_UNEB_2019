
public class Contato implements IF_Contato{
	
	private String nome,telefone;

	@Override
	public String getNome() {
		// TODO Auto-generated method stub
		return this.nome;
	}

	@Override
	public String getTelefone() {
		// TODO Auto-generated method stub
		return this.telefone;
	}

	@Override
	public void setTelefone(String telefone) {
		// TODO Auto-generated method stub
		
		this.telefone =telefone;
		
	}

	@Override
	public void setNome(String nome) {
		// TODO Auto-generated method stub
		this.nome =nome;
	}
	
	public boolean equals(Object o){
		
		Contato c =(Contato)o;
		return this.telefone.equals(c.getTelefone());
		
	}
	
	public String toString(){
		return " Nome: "+this.getNome() +  " Telefone: "+this.getTelefone(); 
	}
	
	public static void main(String args[]){
		IF_Contato c[] = new IF_Contato[2]; 
		c[0]= new Contato();
		c[0].setNome("A");
		c[0].setTelefone("999-9999");
		
		c[1]= new Contato();
		c[1].setNome("B");
		c[1].setTelefone("999-9999");
		
		System.out.println(c[0].equals(c[1]));
		
		
		
		
		
		
		
	}
	
}
	
	
	
	
	
	
	
	



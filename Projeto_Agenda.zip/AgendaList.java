import java.util.*;

public class AgendaList extends Agenda {
	
	private List listaContato = new ArrayList();
	
	public Collection getLista(){
		return this.listaContato;
	}

	
	public boolean adicionaContato(IF_Contato contato) {
		
		if (!this.listaContato.contains(contato)){
			this.listaContato.add(contato);
			return true;
		}else{
		// TODO Auto-generated method stub
			return false;
		}
	}

	
	public IF_Contato getContato(String telefone) {
		
		IF_Contato c = new Contato();
		c.setTelefone(telefone);
		int i = this.listaContato.indexOf(c);
		if (i==-1){
			return null;
		}else{
			return (IF_Contato) this.listaContato.get(i);
		}
		
		
	}

	

	
	public boolean removeContato(String telefone) {
		
		IF_Contato c = new Contato();
		c.setTelefone(telefone);
		int i = this.listaContato.indexOf(c);
		if (i!=-1){
			
			this.listaContato.remove(i);
			return true;
		}else{
			return false;
		}
		
	}

	

}


public interface IF_Contato {
	
	public String getNome();
	public String getTelefone();
	
	public void setTelefone(String telefone);
	
	public void setNome(String nome);

}

import java.util.*;



public abstract class  Agenda {
	
	public abstract boolean adicionaContato(IF_Contato contato);
	
	public abstract IF_Contato getContato(String telefone);
	
	public List getContatoPorNome(String nome){
	    List temp = new ArrayList();
		
		Iterator it = this.getLista().iterator();
		while (it.hasNext()){
			IF_Contato c = (IF_Contato) it.next();
			if (c.getNome().startsWith(nome)){
				temp.add(c);
			}
			
		}
		
		// TODO Auto-generated method stub
		return temp;
	}
	
	public abstract boolean removeContato(String telefone);
	
	public String getListaContato(){
	String temp="Lista Contato \n";
	
		
		Iterator it = this.getLista().iterator();
		while (it.hasNext()){
			IF_Contato c = (IF_Contato) it.next();
			temp = temp+ " Nome: "+c.getNome() +  " Telefone: "+c.getTelefone()+ "\n";
			
			
		}
		// TODO Auto-generated method stub
		return temp;
	}
	
	public abstract Collection getLista();
	
	

}

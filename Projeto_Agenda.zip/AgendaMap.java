import java.util.*;

public class AgendaMap extends Agenda{
	
	private Map listaContato = new HashMap();
	
	public Collection getLista(){
		return this.listaContato.values();
	}

	@Override
	public boolean adicionaContato(IF_Contato contato) {
		
		if (!this.listaContato.containsKey(contato.getTelefone())){
			this.listaContato.put(contato.getTelefone(),contato);
			return true;
		}else{
			return false;
		}
	
	}

	@Override
	public IF_Contato getContato(String telefone) {
		
		if (this.listaContato.containsKey(telefone)){
			
			return (IF_Contato) this.listaContato.get(telefone);
		}else{
			return null;
		}
	
	}

	
	@Override
	public boolean removeContato(String telefone) {

		if (this.listaContato.containsKey(telefone)){
			
			 this.listaContato.remove(telefone);
			 
			 return true;
		}else{
			return false;
		}
	}

	

}

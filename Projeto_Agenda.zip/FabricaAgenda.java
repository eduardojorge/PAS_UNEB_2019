
public class FabricaAgenda {
	
	private static FabricaAgenda fabricaAgenda=null;
	
	public static int AGENDA_LIST=0;
	public static int AGENDA_MAP=1;
	
	
	private FabricaAgenda(){
		
	}
	
	public static FabricaAgenda getInstancia(){
		if (FabricaAgenda.fabricaAgenda==null){
			FabricaAgenda.fabricaAgenda = new FabricaAgenda();
			
		}
		return FabricaAgenda.fabricaAgenda;
	}
	
	public Agenda criaAgenda(int tipo){
		if (tipo==FabricaAgenda.AGENDA_LIST){
			return new AgendaList();
		}else if (tipo==FabricaAgenda.AGENDA_MAP){
			return new AgendaMap();
		}
		return null;
	}
	
	public static void main(String args[]){
		
		Agenda agenda = null;
		agenda= FabricaAgenda.getInstancia().criaAgenda(FabricaAgenda.AGENDA_MAP);
		
		IF_Contato[] c = new IF_Contato[3];
		c[0] = new Contato();
		c[0].setNome("Eduardo Jorge");
		c[0].setTelefone("999-9999");
		agenda.adicionaContato(c[0]);
		
		c[1] = new Contato();
		c[1].setNome("Eduardo Manuel");
		c[1].setTelefone("999-9998");
		agenda.adicionaContato(c[1]);
		
		c[2] = new Contato();
		c[2].setNome("Elisa Maria");
		c[2].setTelefone("999-7777");
		agenda.adicionaContato(c[2]);
		
		System.out.println(agenda.getContato("999-9999").getNome());
		
		System.out.println(agenda.getContatoPorNome("Edu"));
		
		
		System.out.println(agenda.getListaContato());
		
		agenda.removeContato("999-9998");
		
		System.out.println(agenda.getListaContato());
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
